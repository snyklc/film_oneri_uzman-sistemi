﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace film_oneri_uzman_sistemi
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        public void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            if (radioButton1.Checked)
            {
                label3.Visible = true;
                label3.Text = "İYİ SEYİRLER :)";
            }
            if (comboBox1.SelectedIndex == 1 && radioButton2.Checked)
            {
                richTextBox1.Text = "80 GÜNDE DEVRİ ALEM ";
            }
            if (comboBox1.SelectedIndex == 2 && radioButton2.Checked)
            {
                richTextBox1.Text = "AZINLIK RAPORU ";
            }
            if (comboBox1.SelectedIndex == 3 && radioButton2.Checked)
            {
                richTextBox1.Text = "FORD v FERRARI ";
            }
        }
      
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedIndex==0)
            {
                MessageBox.Show("SEÇİM YAPMADINIZ");
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                richTextBox1.Text = "GİZEMLİ ADAYA YOLCULUK";
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                richTextBox1.Text = "INCEPTION";
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                richTextBox1.Text = "HIZLI VE ÖFKELİ";
            }
            if (radioButton1.Checked)
            {
                label3.Visible = true;
                label3.Text = "İYİ SEYİRLER :)";
            }
            else if (comboBox1.SelectedIndex == 1 && radioButton2.Checked)
            {
                richTextBox1.Text = "80 GÜNDE DEVRİ ALEM ";
            }
            else if (comboBox1.SelectedIndex == 2 && radioButton2.Checked)
            {
                richTextBox1.Text = "AZINLIK RAPORU ";
            }
            else if (comboBox1.SelectedIndex == 3 && radioButton2.Checked)
            {
                richTextBox1.Text = "FORD v FERRARI ";
            }
            
        }

      
        
    }
}
